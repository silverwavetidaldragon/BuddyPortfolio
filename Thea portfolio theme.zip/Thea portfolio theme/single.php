<!-- for all posts-->
<?php 
    get_header(); #links to header.php
    while(have_posts()){
        the_post(); ?>
        
             <h2> the post: <?php the_title();?> </h2>
             <p> <?php the_content(); ?></p>
        
    <?php }
    get_footer();

?>