<?php
    function my_first_portfolio_files(){
        wp_enqueue_style('first stylesheet', get_stylesheet_uri()); //arg 1: name arg2: location/path
    }
    add_action('wp_enqueue_scripts','my_first_portfolio_files'); // arg 1: hook wp arg 2_ name our function
?>
