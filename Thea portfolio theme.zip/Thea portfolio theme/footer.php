

        <p> Developed by Iridescence for Hackathon week 12 2023</p>

        <?php wp_footer(); ?>
    </body>
</html>