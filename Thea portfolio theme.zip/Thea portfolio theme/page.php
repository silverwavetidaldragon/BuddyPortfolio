<!-- for secondary pages-->



<?php 
    get_header(); #links to header.php
    #here is within body
   ?>

    <!-- content  -->
        <div class="gridLayout">
            <div class="item" id="one">
            </div>
            <div class="item" id="two">
                <a href="../">
                    <div class="tab-label">
                        Back to page introduction
                    </div>
                </a>
            </div>
            <div class="item box-right" id="three">
                
                <?php 
                    
                    the_post(); ?>
                        
                     <h2> <?php the_title();?> </h2>
                     <p> <?php the_content(); ?></p>
                    
                     <!-- get the page titles as tab label-->
                     <?php
                        $page_ids= get_all_page_ids();
                           
                        $tabs= array(); // in form of id(int)
                        foreach($page_ids as $id)
                            if($id!="3"):{
                                $tabs[]=$id;
                            }
                        endif;

                        

                        
                        
                    ?>

                
            </div>
            <div class="item tab" id="four">
                <a href="./CV">
                    <div class="tab-label">
                        <?php 
                            if(isset($tabs[0])):
                                echo get_the_title($tabs[0]); 
                            endif;
                        ?>
                    </div>
                </a>
            </div>
            <div class="item tab" id="five">
                <a href="./Contact">
                    <div class="tab-label">
                        <?php 
                            if(isset($tabs[1])):
                                echo get_the_title($tabs[1]); 
                            endif;
                        ?>
                    </div>
                </a>
            </div>
            <div class="item tab" id="six">
                <a href="./Experience">
                    <div class="tab-label">
                        <?php 
                            if(isset($tabs[2])):
                                echo get_the_title($tabs[2]); 
                            endif;
                        ?>
                    </div>
                </a>
            </div>
            <div class="item tab" id="seven">
                <a href="./Agenda">
                    <div class="tab-label">
                        <?php 
                            if(isset($tabs[3])):
                                echo get_the_title($tabs[3]); 
                            endif;
                        ?>
                    </div>
                </a>
            </div>
            <div class="item tab" id="eight">
                <div class="tab-label">
                    <?php 
                        if(isset($tabs[4])):
                            echo get_the_title($tabs[4]); 
                        endif;
                    ?>
                </div>
            </div>
            <div class="item tab" id="nine">
                <div class="tab-label">
                    <?php 
                        if(isset($tabs[5])):
                            echo get_the_title($tabs[5]); 
                        endif;
                    ?>
                </div>
            </div>
            <div class="item tab" id="ten">
            </div>

            
        </div>
<?php    
    get_footer();

?>

