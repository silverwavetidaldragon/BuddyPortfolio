<DOCTYPE! html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php wp_head(); ?>  <!-- lets wordpress get referenced and do its magic for header-->
    </head>
    <body>
        <!-- custom header/top part over grid if want -->

